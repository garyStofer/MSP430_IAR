//------------------------------------------------------------------------------
// MSP430F4270 Altimeter Demo - C Language Version - TI LCD
//
// Description:
//   PRESSURE SENSOR IS SAMPLED/AVG'D 64X WITH OSR=1024, fSD16=32kHz, 16-bit
//   TEMP SENSOR IS SAMPLED/AVG'D 1X WITH OSR=1024, fSD16=32kHz, 16-bit
//
//                  MSP430F4270       T.I. MSP-EVK430S320 LCD
//               +---------------+            #T218010
//               |               |    +----------------------+
//   IN+     o---|A0+      S0-Sxx|--->|                      |
//   IN-     o---|A0-   COM0-COM3|--->|            4-Mux LCD |
//   VBridge o--+|P6.6           |    +----------------------+
//              +|P6.7           |
//           o---|VRef           |
//               |               |
//               |       XIN/XOUT|<---32.768KHz Watch Crystal
//               |           P1.6|<---Button (low-active)
//               |           P1.7|<---Button (low-active)
//               |           P1.0|--->LED
//               +---------------+
//
// Andreas Dannenberg
// Texas Instruments Inc.
// June 23rd, 2005
// Built with CCE for MSP430 Version: 1.00
//------------------------------------------------------------------------------
// THIS PROGRAM IS PROVIDED "AS IS". TI MAKES NO WARRANTIES OR
// REPRESENTATIONS, EITHER EXPRESS, IMPLIED OR STATUTORY,
// INCLUDING ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
// FOR A PARTICULAR PURPOSE, LACK OF VIRUSES, ACCURACY OR
// COMPLETENESS OF RESPONSES, RESULTS AND LACK OF NEGLIGENCE.
// TI DISCLAIMS ANY WARRANTY OF TITLE, QUIET ENJOYMENT, QUIET
// POSSESSION, AND NON-INFRINGEMENT OF ANY THIRD PARTY
// INTELLECTUAL PROPERTY RIGHTS WITH REGARD TO THE PROGRAM OR
// YOUR USE OF THE PROGRAM.
//
// IN NO EVENT SHALL TI BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
// CONSEQUENTIAL OR INDIRECT DAMAGES, HOWEVER CAUSED, ON ANY
// THEORY OF LIABILITY AND WHETHER OR NOT TI HAS BEEN ADVISED
// OF THE POSSIBILITY OF SUCH DAMAGES, ARISING IN ANY WAY OUT
// OF THIS AGREEMENT, THE PROGRAM, OR YOUR USE OF THE PROGRAM.
// EXCLUDED DAMAGES INCLUDE, BUT ARE NOT LIMITED TO, COST OF
// REMOVAL OR REINSTALLATION, COMPUTER TIME, LABOR COSTS, LOSS
// OF GOODWILL, LOSS OF PROFITS, LOSS OF SAVINGS, OR LOSS OF
// USE OR INTERRUPTION OF BUSINESS. IN NO EVENT WILL TI'S
// AGGREGATE LIABILITY UNDER THIS AGREEMENT OR ARISING OUT OF
// YOUR USE OF THE PROGRAM EXCEED FIVE HUNDRED DOLLARS
// (U.S.$500).
//
// Unless otherwise stated, the Program written and copyrighted
// by Texas Instruments is distributed as "freeware".  You may,
// only under TI's copyright in the Program, use and modify the
// Program without any charge or restriction.  You may
// distribute to third parties, provided that you transfer a
// copy of this license to the third party and the third party
// agrees to these terms by its first use of the Program. You
// must reproduce the copyright notice and any other legend of
// ownership on each copy or partial copy, of the Program.
//
// You acknowledge and agree that the Program contains
// copyrighted material, trade secrets and other TI proprietary
// information and is protected by copyright laws,
// international copyright treaties, and trade secret laws, as
// well as other intellectual property laws.  To protect TI's
// rights in the Program, you agree not to decompile, reverse
// engineer, disassemble or otherwise translate any object code
// versions of the Program to a human-readable form.  You agree
// that in no event will you alter, remove or destroy any
// copyright notice included in the Program.  TI reserves all
// rights not specifically granted under this license. Except
// as specifically provided herein, nothing in this agreement
// shall be construed as conferring by implication, estoppel,
// or otherwise, upon you, any license or other right under any
// TI patents, copyrights or trade secrets.
//
// You may not use the Program in non-TI devices.
//------------------------------------------------------------------------------

#include <math.h>
#include "msp430x42x0.h"

// Circuit related definitions
#define BRIDGE_SUPPLY       (0xc0)              // IO pins P6.6/P6.7 for
                                                // pos. bridge rail
#define LED1                (0x01)              // LED on P1.0
#define PUSH_BUTTON1        (0x40)              // Button on pin P1.6
#define PUSH_BUTTON2        (0x80)              // Button on pin P1.7

// Constants for math calculations (for altitude/pressure measurement)
#define VREF_VOLT_EXT   (1.26923077f)           // External ref voltage
#define GAIN_32         (28.35f)                // Typ. gain for 32x
#define NR_BITS         (32767)                 // 15 bits of resolution
#define UV_PER_LSB      (1000000.0f * VREF_VOLT_EXT / 2 / GAIN_32 / NR_BITS)
#define MB_PER_UV       (10.0f / 120.0f)        // 10mbar / 120uV @ V_Bridge = 3V
#define NORMAL_P        (1013.25f)              // Normal air pressure in mbar

// Constants for math calculations (for temperature measurement)
#define VREF_VOLT_INT   (1.20f)                 // Internal ref voltage
#define MV_PER_LSB      (1000.0f * VREF_VOLT_INT / 2 / 32767)
#define K_PER_MV        (1.0f / 1.32f)

// Misc definitions
#define MODE_TIMEOUT    (240)                   // Max time for A/P measurement
                                                // (in s)

enum
{
  PM_MEASURE_A,                                 // Mode - Measure Altitude
  PM_MEASURE_P,                                 // Mode - Measure Pressure
  PM_DISPLAY_TIME,                              // Mode - Display Time
  PM_MEASURE_TEMP,                              // Mode - Measure Temperature
  PM_DISPLAY_CONTR,                             // Mode - Display Contrast
  PM_CAL_A,                                     // Mode - Cal Altitude
  PM_CAL_P,                                     // Mode - Cal Pressure
  PM_SET_TIME,                                  // Mode - Set Time
  PM_CAL_TEMP,                                  // Mode - Cal Temperature
  PM_SET_CONTR                                  // Mode - Set Contrast
};

// LCD segment definitions (TI 4-mux LCD)
#define SEG_E   0x80                            //  AAAA
#define SEG_H   0x40                            // F    B
#define SEG_F   0x20                            // F    B
#define SEG_C   0x10                            //  GGGG
#define SEG_G   0x08                            // E    C
#define SEG_D   0x04                            // E    C
#define SEG_B   0x02                            //  DDDD
#define SEG_A   0x01

const char LCD_Tab[] = {
  SEG_A + SEG_B + SEG_C + SEG_D + SEG_E + SEG_F,          // Displays "0"
  SEG_B + SEG_C,                                          // Displays "1"
  SEG_A + SEG_B + SEG_D + SEG_E + SEG_G,                  // Displays "2"
  SEG_A + SEG_B + SEG_C + SEG_D + SEG_G,                  // Displays "3"
  SEG_B + SEG_C + SEG_F + SEG_G,                          // Displays "4"
  SEG_A + SEG_C + SEG_D + SEG_F + SEG_G,                  // Displays "5"
  SEG_A + SEG_C + SEG_D + SEG_E + SEG_F + SEG_G,          // Displays "6"
  SEG_A + SEG_B + SEG_C,                                  // Displays "7"
  SEG_A + SEG_B + SEG_C + SEG_D + SEG_E + SEG_F + SEG_G,  // Displays "8"
  SEG_A + SEG_B + SEG_C + SEG_D + SEG_F + SEG_G,          // Displays "9"
  SEG_A + SEG_B + SEG_C + SEG_E + SEG_F + SEG_G,          // Displays "A"
  SEG_B + SEG_C + SEG_E + SEG_F + SEG_G,                  // Displays "H"
  SEG_A + SEG_D + SEG_E + SEG_F,                          // Displays "C"
  SEG_D + SEG_E + SEG_F,                                  // Displays "L"
  SEG_A + SEG_B + SEG_E + SEG_F + SEG_G,                  // Displays "P"
  0x00                                                    // Displays Blank
};

#define DIG_MINUS   (SEG_G)                               // Displays '-'
#define DIG_T       (SEG_D + SEG_E + SEG_F + SEG_G)       // Displays 't'
#define DIG_DEGR    (SEG_A + SEG_B + SEG_F + SEG_G)
#define DIG_F       (SEG_A + SEG_E + SEG_F + SEG_G)       // Displays 'F'
#define DIG_L       (SEG_D + SEG_E + SEG_F)               // Displays 'L'
#define DIG_O       (SEG_A + SEG_B + SEG_C + SEG_D + SEG_E + SEG_F) // Displays 'O'
#define DIG_H       (SEG_B + SEG_C + SEG_E + SEG_F + SEG_G)         // Displays 'H'
#define DIG_I       (SEG_B + SEG_C)                          // Displays 'I'
#define DIG_C       (SEG_A + SEG_D + SEG_E + SEG_F)          // Displays 'C'
#define DIG_D       (SEG_B + SEG_C + SEG_D + SEG_E + SEG_G)  // Displays 'd'
#define DIG_N       (SEG_C + SEG_E + SEG_G)                  // Displays 'n'
#define DIG_E       (SEG_A + SEG_D + SEG_E + SEG_F + SEG_G)  // Displays 'E'
#define DIG_S       (SEG_A + SEG_C + SEG_D + SEG_F + SEG_G)  // Displays 'S'

// Global vars for SD16 operation
static unsigned int SD16TempCtr;                // Number of resuts collected
static long SD16Temp;                           // Temp sum register
static long SD16Result;                         // Final averaged result
static unsigned int SD16NrConversions;

// Global vars that control program flow
static unsigned char ProgramMode = PM_DISPLAY_TIME; // Current program mode
static unsigned char PB1DownCtr = 0;            // Keeps track of button press
static unsigned char PB2DownCtr = 0;            // duration
static unsigned int StatusFlags = 0;            // Status flag register
static unsigned char ModeCtr = 0;               // Time in current mode [s]

#define SF_BT_TICK        0x0001                // Status flags bit definitions
#define SF_PB1_RELEASED   0x0002
#define SF_PB2_RELEASED   0x0004
#define SF_SD16_START     0x0008
#define SF_SD16_READY     0x0010
#define SF_UPD_DISPLAY    0x0020
#define SF_PB1_PRESSED    0x0040
#define SF_PB2_PRESSED    0x0080
#define SF_PB1_DOWN       0x0100
#define SF_PB2_DOWN       0x0200
#define SF_HOLD_DISPL     0x0400

#define AF_DISPLAY_DEGF   0x01

static int CalConstA;                           // Temporary cal vars
static int CalConstP;
static int CalConstT;
static char DispContr;                          // Display contrast setting
static char AppFlags;                           // Misc application flags

// Global vars for RTC
static unsigned char Secs = 0x00;               // RTC, default time 12:00:00
static unsigned char Mins = 0x00;
static unsigned char Hrs = 0x12;

#pragma DATA_SECTION(CalConstA_Flash, ".infoA") // Info Flash Memory Block A
static int CalConstA_Flash;                     // Cal const for altitude
#pragma DATA_SECTION(CalConstP_Flash, ".infoA") // Info Flash Memory Block A
static int CalConstP_Flash;                     // Cal const for pressure
#pragma DATA_SECTION(CalConstT_Flash, ".infoA") // Info Flash Memory Block A
static int CalConstT_Flash;                     // Cal const for temperature
#pragma DATA_SECTION(DispContr_Flash, ".infoA") // Info Flash Memory Block A
static char DispContr_Flash;                    // Const for display contrast
#pragma DATA_SECTION(AppFlags_Flash, ".infoA")  // Info Flash Memory Block A
static char AppFlags_Flash;                     // Misc application flags

// Function prototypes
void Init_Sys(void);
unsigned short _bcd_add_short(unsigned short a, unsigned short b);
void RTC_Tick(unsigned int TickMins);
void RTC_Dec(unsigned int TickMins);
void InitConversion(void);
void StartNextConversion(void);
void StopConversion(void);
void StoreCalInFlash(void);
void Disp_Value(unsigned int ShiftLeft, int Value);
void Disp_BCD(unsigned long Value);
//------------------------------------------------------------------------------
void main(void)
{
  Init_Sys();

  CalConstA = CalConstA_Flash;                  // Load calibration constants
  CalConstP = CalConstP_Flash;
  CalConstT = CalConstT_Flash;
  DispContr = DispContr_Flash == 0xff ? 0 : DispContr_Flash;
  AppFlags = AppFlags_Flash;

  __enable_interrupt();

  Disp_BCD(0x08888888);                         // Test LCD (all segs on)

  while (1)
  {
    __bis_SR_register(LPM3_bits);               // Enter LPM3, wait for wakeup

    if (StatusFlags & SF_BT_TICK)
    {
      RTC_Tick(0);                              // Advance RTC seconds

      switch (ProgramMode)
      {
        case PM_MEASURE_A :
        case PM_MEASURE_P :
          if (++ModeCtr > MODE_TIMEOUT)         // Timeout?
          {
            StopConversion();
            ProgramMode = PM_DISPLAY_TIME;      // Exit current mode
            StatusFlags |= SF_UPD_DISPLAY;      // Update RTC display
          }
          break;
        case PM_CAL_A  :
        case PM_CAL_P  :
                                                // No action here. Next SD16
                                                // conversion is started
                                                // directly after current.
          break;
        case PM_MEASURE_TEMP :
        case PM_CAL_TEMP :
          StatusFlags |= SF_SD16_START;         // Trigger SD16 conversion
          break;
        case PM_DISPLAY_TIME :
        case PM_SET_TIME :
          StatusFlags |= SF_UPD_DISPLAY;        // Update RTC display
          break;
      }
      StatusFlags &= ~SF_BT_TICK;               // Event processed
    }

    if (((StatusFlags & (SF_PB1_PRESSED + SF_PB2_PRESSED)) ==
        SF_PB1_PRESSED + SF_PB2_PRESSED) && (PB1DownCtr > 62) &&
        (PB2DownCtr > 62))

    // Both buttons pressed for >1s
    {
      switch (ProgramMode)                      // Yes, update Program Mode
      {
        case PM_MEASURE_A :
          ProgramMode = PM_CAL_A;
          Disp_BCD(0x0fcadfff);                 // Display 'CAL    '
          StatusFlags |= SF_HOLD_DISPL;         // Hold display contents
          break;
        case PM_MEASURE_P :
          ProgramMode = PM_CAL_P;
          Disp_BCD(0x0fcadfff);                 // Display 'CAL    '
          StatusFlags |= SF_HOLD_DISPL;         // Hold display contents
          break;
        case PM_DISPLAY_TIME :
          ProgramMode = PM_SET_TIME;
          LCDM1 = 0x00;                         // Display 'SEt    '
          LCDM2 = DIG_T;
          LCDM3 = DIG_E;
          LCDM4 = DIG_S;
          LCDM5 = 0x00;
          LCDM6 = 0x00;
          LCDM7 = 0x00;
          StatusFlags |= SF_HOLD_DISPL;         // Hold display contents
          break;
        case PM_MEASURE_TEMP :
          ProgramMode = PM_CAL_TEMP;
          Disp_BCD(0x0fcadfff);                 // Display 'CAL    '
          StatusFlags |= SF_HOLD_DISPL;         // Hold display contents
          break;
        case PM_DISPLAY_CONTR :
          ProgramMode = PM_SET_CONTR;
          LCDM1 = 0x00;                         // Display 'SEt    '
          LCDM2 = DIG_T;
          LCDM3 = DIG_E;
          LCDM4 = DIG_S;
          LCDM5 = 0x00;
          LCDM6 = 0x00;
          LCDM7 = 0x00;
          StatusFlags |= SF_HOLD_DISPL;         // Hold display contents
          break;
        case PM_CAL_A  :
          ProgramMode = PM_MEASURE_A;
          StoreCalInFlash();
          break;
        case PM_CAL_P :
          ProgramMode = PM_MEASURE_P;
          StoreCalInFlash();
          break;
        case PM_SET_TIME :
          ProgramMode = PM_DISPLAY_TIME;
          LCDM1 = 0x00;                         // Clear display and output
          LCDM2 = DIG_E;                        // 'done'
          LCDM3 = DIG_N;
          LCDM4 = DIG_O;
          LCDM5 = DIG_D;
          LCDM6 = 0x00;
          LCDM7 = 0x00;
          StatusFlags |= SF_HOLD_DISPL;         // Hold display contents
          break;
        case PM_CAL_TEMP :
          ProgramMode = PM_MEASURE_TEMP;
          StoreCalInFlash();
          break;
        case PM_SET_CONTR :
          ProgramMode = PM_DISPLAY_CONTR;
          StoreCalInFlash();
          break;
      }
      StatusFlags &= ~(SF_PB1_PRESSED + SF_PB2_PRESSED);
    }
    else if ((StatusFlags & SF_PB1_PRESSED) && (PB1DownCtr > 124))
    {
      switch (ProgramMode)
      {
        case PM_CAL_A :
          CalConstA -= 5;
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_CAL_P :
          CalConstP -= 5;
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_SET_TIME :
          RTC_Dec(1);                           // Decrement minutes
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_CAL_TEMP :
          CalConstT--;
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
      }
    }
    else if ((StatusFlags & SF_PB1_RELEASED) && (PB1DownCtr < 62))
    {
      switch (ProgramMode)
      {
        case PM_MEASURE_A :
          StopConversion();
          ProgramMode = PM_MEASURE_P;
          InitConversion();
          StatusFlags |= SF_SD16_START;
          ModeCtr = 0;                          // Reset timeout counter
          break;
        case PM_MEASURE_P :
          StopConversion();
          ProgramMode = PM_DISPLAY_TIME;
          break;
        case PM_DISPLAY_TIME :
          ProgramMode = PM_MEASURE_TEMP;
          InitConversion();
          StatusFlags |= SF_SD16_START;
          break;
        case PM_MEASURE_TEMP :
          StopConversion();
          ProgramMode = PM_DISPLAY_CONTR;
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_DISPLAY_CONTR :
          ProgramMode = PM_MEASURE_A;
          InitConversion();
          StatusFlags |= SF_SD16_START;
          ModeCtr = 0;                          // Reset timeout counter
          break;
        case PM_CAL_A  :
          CalConstA--;
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_CAL_P :
          CalConstP--;
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_SET_TIME :
          RTC_Dec(1);                           // Decrement minutes
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_CAL_TEMP :
          CalConstT--;
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_SET_CONTR :
          if (DispContr) DispContr--;           // Decrement if possible
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
      }
      StatusFlags &= ~SF_PB1_RELEASED;
    }
    else if ((StatusFlags & SF_PB2_PRESSED) && (PB2DownCtr > 124))
    {
      switch (ProgramMode)                      // Do set/calibration
      {
        case PM_MEASURE_TEMP :
          AppFlags ^= AF_DISPLAY_DEGF;          // Toggle DegC/DegF
          StoreCalInFlash();
          StatusFlags &= ~SF_PB2_PRESSED;
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_CAL_A  :
          CalConstA += 5;
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_CAL_P :
          CalConstP += 5;
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_SET_TIME :
          RTC_Tick(1);                          // Increment minutes
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_CAL_TEMP :
          CalConstT++;
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
      }
    }
    else if ((StatusFlags & SF_PB2_RELEASED) && (PB2DownCtr < 62))
    {
      switch (ProgramMode)                      // Do set/calibration
      {
        case PM_CAL_A  :
          CalConstA++;
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_CAL_P :
          CalConstP++;
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_SET_TIME :
          RTC_Tick(1);                          // Increment minutes
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_CAL_TEMP :
          CalConstT++;
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        case PM_SET_CONTR :
          if (DispContr < 15) DispContr++;      // Increment if possible
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
        default :
          LCDACTL ^= LCDON;                     // LCD on/off
          StatusFlags |= SF_UPD_DISPLAY;        // Force display update
          break;
      }
      StatusFlags &= ~SF_PB2_RELEASED;
    }

    if (StatusFlags & SF_SD16_READY)
    {
      switch (ProgramMode)
      {
        case PM_MEASURE_A :
        case PM_MEASURE_P :
        case PM_CAL_A :
        case PM_CAL_P :
          SD16Result = SD16Temp >> 6;           // Calculate result (div 64)
          StatusFlags |= SF_SD16_START;         // Trigger SD16 conversion
          break;
        case PM_MEASURE_TEMP :
        case PM_CAL_TEMP :
          SD16Result = SD16Temp;                // Move result
          break;
      }
      StatusFlags |= SF_UPD_DISPLAY;            // Request display update
      StatusFlags &= ~SF_SD16_READY;            // Event processed
    }

    if (StatusFlags & SF_SD16_START)
    {
      StartNextConversion();                    // Start SD16 conversions
      StatusFlags &= ~SF_SD16_START;            // Event processed
    }

    if (StatusFlags & SF_UPD_DISPLAY)           // Display update requested?
    {
      if (StatusFlags & SF_HOLD_DISPL)          // Preserve display contents?
      {
        StatusFlags &= ~SF_HOLD_DISPL;          // Event processed
      }
      else
      {
        LCDAVCTL1 = DispContr << 1;             // Set LCDA charge pump voltage

        switch (ProgramMode)
        {
          case PM_MEASURE_A :
          case PM_CAL_A :
            Disp_BCD(0x0fafffff);               // Display 'A     '
            Disp_Value(0, 18400.0f *
              log(NORMAL_P / ((float)SD16Result * UV_PER_LSB * MB_PER_UV)) +
              CalConstA);                       // Display in meter
            break;
          case PM_MEASURE_P :
          case PM_CAL_P :
            Disp_BCD(0x0fefffff);               // Display 'P     '
            Disp_Value(0, (float)SD16Result * UV_PER_LSB * MB_PER_UV +
              CalConstP);
           break;
          case PM_DISPLAY_TIME :
          case PM_SET_TIME :
            Disp_BCD(0x0f000000 + ((long)Hrs << 16) + ((int)Mins << 8) + Secs);
            break;
          case PM_MEASURE_TEMP :
          case PM_CAL_TEMP :
            Disp_BCD(0x0fffffff);               // Clear display

            if (Secs & 0x01)                    // Blink degree sign
              LCDM2 = DIG_DEGR;

            if (AppFlags & AF_DISPLAY_DEGF)     // Temp display in Deg F?
            {
              LCDM1 = DIG_F;                    // Display 'F'
              Disp_Value(2, (float)SD16Result * MV_PER_LSB * K_PER_MV * 9 / 5 -
                273 * 9 / 5 + 32 + CalConstT);
            }
            else
            {
              LCDM1 = DIG_C;                    // Display 'C'
              Disp_Value(2, (float)SD16Result * MV_PER_LSB * K_PER_MV - 273 +
                CalConstT);
            }
            break;
          case PM_DISPLAY_CONTR :
          case PM_SET_CONTR :
            if (DispContr)
            {
              Disp_BCD(0x0fceffff);             // Display 'CP    '
              Disp_Value(0, DispContr);         // Contrast value
            }
            else
            {
              Disp_BCD(0x0fceffff);             // Display 'CP    '
              LCDM1 = DIG_F;                    // Display '   OFF'
              LCDM2 = DIG_F;
              LCDM3 = DIG_O;
            }
            break;
        }
        StatusFlags &= ~SF_UPD_DISPLAY;         // Event processed
      }
    }
  }
}
//------------------------------------------------------------------------------
void Init_Sys(void)
{
  int i;
  char *pLCD = (char *)&LCDM1;

  WDTCTL = WDTPW + WDTHOLD;                     // Stop WDT
  FLL_CTL0 |= XCAP18PF;                         // Set load capacitance for xtal

  for (i = 0; i < 20; i++)                      // Clear LCD memory
    *pLCD++ = 0;

  LCDACTL = LCDFREQ_96 + LCD4MUX + LCDON;       // 4mux LCD, set LCD freq
  LCDAPCTL0 = 0x0F;                             // Segs S0-S15 = outputs
  LCDAVCTL0 = LCDCPEN;                          // Enable LCDA charge pump

  BTCTL = BTDIV + BT_fCLK2_DIV128;              // 1s BT int
  IE2 |= BTIE;                                  // Enable Basic Timer interrupt

  P1OUT = 0x00;                                 // P1OUTs = 0
  P1DIR = 0xff & ~(PUSH_BUTTON1 + PUSH_BUTTON2);// Unused pins as outputs
  P1IES = PUSH_BUTTON1 + PUSH_BUTTON2;          // Button ints on falling edge
  P1IFG = 0x00;                                 // Clear P1 int flags
  P1IE = PUSH_BUTTON1 + PUSH_BUTTON2;           // Enable button interrupts
  P5SEL = 0xff;                                 // Set Rxx and COM pins for LCD
  P6OUT = 0x00;                                 // P6OUTs = 0
  P6DIR = 0xff;                                 // Unused pins as outputs
  P6SEL = 0x03;                                 // Select analog function
}
//------------------------------------------------------------------------------
// Do a BCD addition of two short variables. Inline-assembly is used
// to achieve an efficient solution. Note that the compiler warning
// about a missing 'return' statement can be ignored as the return
// register is directly modified.
//------------------------------------------------------------------------------
unsigned short _bcd_add_short(unsigned short a, unsigned short b)
{
  asm(" clrc");
  asm(" dadd.w R13,R12");
}
//------------------------------------------------------------------------------
// Advance RTC counter variables
//
// TickMins == 0 --> advance seconds
// TickMins == 1 --> advance minutes
//------------------------------------------------------------------------------
void RTC_Tick(unsigned int TickMins)
{
  Secs = _bcd_add_short(Secs, 1);
  if ((Secs == 0x60) || TickMins)
  {
    Secs = 0x00;
    Mins = _bcd_add_short(Mins, 1);
    if (Mins == 0x60)
    {
      Mins = 0x00;
      Hrs = _bcd_add_short(Hrs, 1);
      if (Hrs == 0x13)
        Hrs = 0x01;
    }
  }
}
//------------------------------------------------------------------------------
// Decrement RTC counter variables
//
// TickMins == 0 --> decrement seconds
// TickMins == 1 --> decrement minutes
//------------------------------------------------------------------------------
void RTC_Dec(unsigned int TickMins)
{
  Secs = _bcd_add_short(Secs, 0x9999);
  if ((Secs == 0x99) || TickMins)
  {
    Secs = TickMins ? 0x00 : 0x59;
    Mins = _bcd_add_short(Mins, 0x9999);
    if (Mins == 0x99)
    {
      Mins = 0x59;
      Hrs = _bcd_add_short(Hrs, 0x9999);
      if (Hrs == 0x00)
        Hrs = 0x12;
    }
  }
}
//------------------------------------------------------------------------------
// Programs the calibration constants into Flash info memory segment A
// using in-system self programming techniques. LED1 will be lit to
// indicate the programming process.
//------------------------------------------------------------------------------
void StoreCalInFlash(void)
{
  volatile unsigned int i;
  
  P1OUT |= LED1;                                // Enable LED1

  FCTL2 = FWKEY + FSSEL1 + FN1;                 // SMCLK/3 = ~333kHz
  FCTL3 = FWKEY;                                // Clear LOCK
  FCTL1 = FWKEY + ERASE;                        // Enable segment erase
  *(unsigned int *)0x1080 = 0;                  // Dummy write, erase info A
  FCTL1 = FWKEY + WRT;                          // Enable write
  CalConstA_Flash = CalConstA;                  // Program calibration constants
  CalConstP_Flash = CalConstP;
  CalConstT_Flash = CalConstT;
  DispContr_Flash = DispContr;
  AppFlags_Flash = AppFlags;
  FCTL1 = FWKEY;                                // Done. Clear WRT
  FCTL3 = FWKEY + LOCK;                         // Done. Set LOCK

  LCDM1 = 0x00;                                 // Clear display and output
  LCDM2 = DIG_E;                                // 'done'
  LCDM3 = DIG_N;
  LCDM4 = DIG_O;
  LCDM5 = DIG_D;
  LCDM6 = 0x00;
  LCDM7 = 0x00;

  for (i = 10000; i > 0; i--);                  // SW delay for LED
  P1OUT &= ~LED1;                               // Disable LED1

  StatusFlags |= SF_HOLD_DISPL;                 // Hold display contents
}
//------------------------------------------------------------------------------
// Converts the 16-Bit integer number 'Value' to BCD and outputs it
// on the LCD display. The position of the the leftmost digit is used
// to indicate sign information.
//------------------------------------------------------------------------------
void Disp_Value(unsigned int ShiftLeft, int Value)
{
  unsigned int i;
  unsigned int Output;
  char fNeg = 0;
  char *pLCD = (char *)&LCDM1 + ShiftLeft;

  if (Value < 0)                                // Test for negative value
  {
    Value = -Value;                             // Negate value
    fNeg = 1;                                   // Set negative flag
  }

  if (Value > 9999)                             // Perform range check
  {
    if (fNeg)
    {
      *pLCD++ = DIG_O;                          // Number too small
      *pLCD = DIG_L;
    }
    else
    {
      *pLCD++ = DIG_I;                          // Number too large
      *pLCD = DIG_H;
    }
    return;                                     // Stop processing here
  }

  for (i = 16, Output = 0; i; i--)              // BCD Conversion, 16-Bit
  {
    Output = _bcd_add_short(Output, Output);
    if (Value & 0x8000)
      Output = _bcd_add_short(Output, 1);
    Value <<= 1;
  }

  for (i = 4; i; i--)                           // Process 4 digits
  {
    *pLCD++ = LCD_Tab[Output & 0x0f];           // Segments to LCD
    Output >>= 4;                               // Process next digit
    if (Output == 0 || i == 1)                  // Leading zeros or last dig.?
    {
      if (fNeg)                                 // Append sign info
        *pLCD = DIG_MINUS;
      break;                                    // Stop processing
    }
  }
}
//------------------------------------------------------------------------------
// Displays the BCD number 'Value' on the LCD display
// 7 digits are output
//------------------------------------------------------------------------------
void Disp_BCD(unsigned long Value)
{
  char *pLCD = (char *)&LCDM1;
  int i;

  for (i = 0; i < 7; i++)                       // Process 7 digits
  {
    *pLCD++ = LCD_Tab[Value & 0x0f];            // Segments to LCD
    Value >>= 4;                                // Process next digit
  }
}
//------------------------------------------------------------------------------
void InitConversion(void)
{
  switch (ProgramMode)                          // Prepare SD16 conversion
  {
    case PM_MEASURE_A :
    case PM_MEASURE_P :
    case PM_CAL_A :
    case PM_CAL_P :
      P6OUT |= BRIDGE_SUPPLY;                   // Power-up bridge sensor
      SD16CTL = SD16SSEL_2;                     // Use ACLK for SD16
      SD16INCTL0 = SD16GAIN_32 + SD16INCH_0;    // 32x gain, channel pair A0
      SD16CCTL0 = SD16BUF_1 + SD16OSR_1024 + SD16DF + SD16IE;
                                                // Continuous conv., 2s compl.
      break;
    case PM_MEASURE_TEMP :
    case PM_CAL_TEMP :
      SD16CTL = SD16SSEL_2;                     // Use ACLK
      SD16INCTL0 = SD16GAIN_1 + SD16INCH_6;     // 1x gain, channel pair A6
      SD16CCTL0 = SD16OSR_1024 + SD16DF + SD16IE;  // Continuous conv., 2s compl.
      break;
  }
}
//------------------------------------------------------------------------------
void StartNextConversion(void)
{
  SD16Temp = 0;
  SD16TempCtr = 0;

  switch (ProgramMode)                          // Start SD16 conversion
  {
    case PM_MEASURE_A :
    case PM_MEASURE_P :
    case PM_CAL_A :
    case PM_CAL_P :
      SD16NrConversions = 64;                   // Average 64 results
      break;
    case PM_MEASURE_TEMP :
    case PM_CAL_TEMP :
      SD16NrConversions = 1;                    // Don't use averaging
      SD16CTL |= SD16VMIDON + SD16REFON;        // Enable Vref
      // Now use Timer_A to allow a defined time for voltages to settle
      TAR = 65535 - 163;                        // Delay 164 ACLK cycles (~5ms)
      TACTL = TASSEL_1 + MC_2;                  // ACLK, start continuous mode
      while (!(TACTL & TAIFG));                 // Wait for TAR overflow
      TACTL = 0x00;                             // Stop Timer_A
      break;
  }

  SD16CCTL0 |= SD16SC;                          // Start conversion
}
//------------------------------------------------------------------------------
void StopConversion(void)
{
  SD16CCTL0 &= ~SD16SC;                         // Disable conversions

  switch (ProgramMode)
  {
    case PM_MEASURE_A :
    case PM_MEASURE_P :
    case PM_CAL_A :
    case PM_CAL_P :
      P6OUT &= ~BRIDGE_SUPPLY;                  // Power-down bridge sensor
      break;
    case PM_MEASURE_TEMP :
    case PM_CAL_TEMP :
      SD16CTL = 0x00;                           // Disable SD16 reference
      break;
  }
}
//------------------------------------------------------------------------------
// The SD16 ISR is executed upon SD16 conversion completion.
//------------------------------------------------------------------------------
__interrupt void SD16ISR(void)
{
  SD16Temp += (long)(int)SD16MEM0;              // Read 15+1 bits

  if (++SD16TempCtr >= SD16NrConversions)       // Enough samples taken?
  {
    SD16CCTL0 &= ~SD16SC;                       // Disable conversions
    SD16CTL &= ~(SD16VMIDON + SD16REFON);       // Disable SD16 reference
    StatusFlags |= SF_SD16_READY;               // Conversion result ready
    __bic_SR_register_on_exit(LPM3_bits);       // Exit LPM3 on ISR exit
  }
}
SD16_ISR(SD16ISR)                               // Assign ISR Vector
//------------------------------------------------------------------------------
// The Basic Timer ISR is executed every 1s and used to wake up the
// main program from low-power mode.
//------------------------------------------------------------------------------
__interrupt void BT_ISR(void)
{
  StatusFlags |= SF_BT_TICK;                    // Indicate Basic Timer tick
  __bic_SR_register_on_exit(LPM3_bits);         // Exit LPM3 on ISR exit
}
BASICTIMER_ISR(BT_ISR)                          // Assign ISR Vector
//------------------------------------------------------------------------------
// The Port 1 ISR is executed on detection of a push-button press.
//------------------------------------------------------------------------------
__interrupt void PORT1ISR(void)
{
  P1IE &= ~(PUSH_BUTTON1 + PUSH_BUTTON2);       // Disable button interrupts
  WDTCTL = WDT_ADLY_16;                         // WDT as 16ms interval timer
  IFG1 &= WDTIFG;
  IE1 |= WDTIE;                                 // Enable WDT interrupt
}
PORT1_ISR(PORT1ISR)                             // Assign ISR Vector
//------------------------------------------------------------------------------
// The WDT ISR is executed periodically after a push-button press was detected
// to poll the port pins and update various push-button status variables.
//------------------------------------------------------------------------------
__interrupt void WDTISR(void)
{
  if (P1IFG & PUSH_BUTTON1)                     // Was button 1 pressed?
  {
    if (!(StatusFlags & SF_PB1_DOWN))           // Press detected?
    {
      PB1DownCtr = 0;                           // Reset 'down' counter
      StatusFlags |= SF_PB1_DOWN;
      StatusFlags |= SF_PB1_PRESSED;            // Button got pressed
      StatusFlags &= ~SF_PB1_RELEASED;
    }
    if (P1IN & PUSH_BUTTON1)                    // Button released?
    {
      P1IFG &= ~PUSH_BUTTON1;                   // Clear int flag
      StatusFlags &= ~SF_PB1_DOWN;
      StatusFlags &= ~SF_PB1_PRESSED;           // Button got released
      StatusFlags |= SF_PB1_RELEASED;
    }
    if (PB1DownCtr != 0xff) PB1DownCtr++;       // Increment button counter
    __bic_SR_register_on_exit(LPM3_bits);       // Exit LPM3 on ISR exit
  }

  if (P1IFG & PUSH_BUTTON2)                     // Was button 2 pressed?
  {
    if (!(StatusFlags & SF_PB2_DOWN))           // Press detected?
    {
      PB2DownCtr = 0;                           // Reset 'down' counter
      StatusFlags |= SF_PB2_DOWN;
      StatusFlags |= SF_PB2_PRESSED;            // Button got pressed
      StatusFlags &= ~SF_PB2_RELEASED;
    }
    if (P1IN & PUSH_BUTTON2)                    // Button released?
    {
      P1IFG &= ~PUSH_BUTTON2;                   // Clear int flag
      StatusFlags &= ~SF_PB2_DOWN;
      StatusFlags &= ~SF_PB2_PRESSED;           // Button got released
      StatusFlags |= SF_PB2_RELEASED;
    }
    if (PB2DownCtr != 0xff) PB2DownCtr++;       // Increment button counter
    __bic_SR_register_on_exit(LPM3_bits);       // Exit LPM3 on ISR exit
  }

  if (!(P1IFG & (PUSH_BUTTON1 + PUSH_BUTTON2))) // Buttons clear?
  {
    WDTCTL = WDTPW + WDTHOLD;                   // Stop WDT
    P1IE |= PUSH_BUTTON1 + PUSH_BUTTON2;        // Enable button interrupts
  }
}
WDT_ISR(WDTISR)                                 // Assign ISR Vector
//------------------------------------------------------------------------------
