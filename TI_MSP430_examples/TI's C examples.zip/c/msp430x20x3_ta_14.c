//******************************************************************************
//  MSP430F20xx Demo - Timer_A, Toggle P1.1/TA0, Up/Down Mode, 32kHz ACLK
//
//  Description: Toggle P1.1 using hardware TA0 output. Timer_A is configured
//  for up/down mode with CCR0 defining period, TA0 also output on P1.1. In
//  this example, CCR0 is loaded with 5 and TA0 will toggle P1.1 at TACLK/2*5.
//  Thus the output frequency on P1.1 will be the TACLK/20. No CPU or software
//  resources required. Normal operating mode is LPM3.
//  ACLK = TACLK = 32kHz, MCLK = default DCO
//  As coded with TACLK = ACLK, P1.1 output frequency = 32768/20 = 1.6384kHz
//  //* External watch crystal installed on XIN XOUT is required for ACLK *//
//
//            MSP430F20xx
//         -----------------
//     /|\|              XIN|-
//      | |                 | 32 kHz
//      --|RST          XOUT|-
//        |                 |
//        |         P1.1/TA0|--> ACLK/20
//
//  M. Buccini / L. Westlund
//  Texas Instruments Inc.
//  October 2005
//  Built with IAR Embedded Workbench Version: 3.40A
//******************************************************************************

#include  <msp430x20x3.h>


void main(void)
{
  WDTCTL = WDTPW + WDTHOLD;                 // Stop WDT
  P1DIR |= 0x02;                            // P1.1 output
  P1SEL |= 0x02;                            // P1.1 option select
  CCTL0 = OUTMOD_4;                         // CCR0 toggle mode
  CCR0 = 5;
  TACTL = TASSEL_1 + MC_3;                  // ACLK, up-downmode

  _BIS_SR(LPM3_bits);                       // Enter LPM3
}
