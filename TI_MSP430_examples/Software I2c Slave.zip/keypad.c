
#include <msp430x11x1.h>
/*
;-------------------------------------------------------------------------------
; Name: i2c_ir_keypad.c
; Func: Key pad scanning
; Ver.: 1.1
; Date: June-2005
; Auth: Thomas Kot
;       MSP430
;       Texas Instruments Inc.
; Rem.: Build with IAR EW V4.3A
;-------------------------------------------------------------------------------
*/

extern void INIT_IIC(void);
extern void INIT_COM(void);
extern char RAM[16];


const int key_code[16] = {  0xFC,0x03,      // key code represents the key pressed
                            0xF0,0x0F,
                            0xF3,0x0C,
                            0xF2,0x0D,
                            0xF1,0x0E,
                            0xE9,0x16,
                            0xED,0x12,
                            0xE1,0x1E};


void delay(unsigned int delay_time)         // delay_timer = number of 1ms
{
  unsigned int delay_counter;

  delay_time *= 1600;
  for (delay_counter = 0; delay_counter < delay_time; delay_counter++)
  _NOP();
}


void check_key_press(void)
{
  char i,key_check;
  if ((P2IN & 0X02) != 0X02)                // single test key
  {
    if (( TACCTL1 & CCIE ) == CCIE)         // check if I2C and IR routine not activated
      if (( P2IE & 0X01) == 0X01)
      {
        _DINT();                            // disable interrupt
        delay(30);                          // delay 30ms for key debounce

        for (i = 0; i < 1; i++)             // check which key is pressed in Port2
        {
          key_check = 0x01;
          key_check <<= i+1;
          if ((P2IN & key_check) != key_check)
          {
            RAM[1] = key_code[2*i];
            RAM[2] = key_code[2*i + 1];
            P1OUT |= 0x02;
          }
        }
        _EINT();
      }
    for (i = 0; i<30; i++)
    {
      delay(33);                            // delay 1sec
      if ((P2IN & 0X02) == 0X02)            // single test key
        break;
    }

    while ((P2IN & 0X02) != 0X02)           // ONE KEY TEST
    {
      delay(33);                            // delay 0.1sed
      delay(33);
      delay(33);
      P1OUT |= 0x02;
    }
  }
}


void main(void)
{
  WDTCTL = WDTPW + WDTHOLD;                 // Stop watchdog

  DCOCTL  = DCO2 + DCO1;
  BCSCTL1 = XT2OFF + RSEL2 + RSEL1 + RSEL0;
  BCSCTL2 = DIVS_3 + DCOR;                  // DCO with ext resistor, 8MHz
                                            // SMCLK = 8MHz / 8

  INIT_IIC();                               // Init I2C setting in i2c_isr.s43
  INIT_COM();                               // Init the setting in iic_ir_common.s43



  P1DIR &= ~0xF8;                           // P1.7,6,5,4,3 as input
  P2DIR &= ~0x0E;                           // P2.1,2,3 as input

  _EINT();

  while(1)
  {
    while(( P1OUT & 0X02) == 0X02) ;        // wait until data fetched
    check_key_press();
  }
}
