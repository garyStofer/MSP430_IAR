In this software-i2c pack, The slave device includes the following files:

i2c_isr.s43               --------------  software slave I2C routine
ir_decode.s43           --------------  IR remote control receiver routine
i2c_ir_common.s43   --------------  it contains common setting for i2c_isr.s43 and ir_decode.s43
keypad.c                  --------------  this is a C code for keypad. main() is in this code.


To verify the I2C communication link, a firmware for master side is included:

XT2_timer_master_AA55.c  -------------- using MSPF169, for I2C master.

For each communication, it will transmit the I2C data through UART to PC. 
Using Hyper-terminal of windows, setting at 19200bps, 8 bit, 1 stop bit, non-parity, one can check the data transmitted or received in I2C link.

 with XT2_timer_master_AA55.c , some commands are created, all in lowcase.
One can type in the following command in the hyper-terminal to instruct the master device to do predefined functions.

  clr -------- clear up the screen in hyper terminal
  a5 -------- looptest on AA 55 ,..... ; send and recieve through I2C
  rand ------ looptest on 01 02 03 ,.........; send and recieve through I2C
  rx   ------- read 15 char from slave , .........
  press any key and press "enter" --------- send to slave
