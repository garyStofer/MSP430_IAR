//******************************************************************************
//   MSP-FET430P169 Demo -
//
//
//
//                                                     MSP430x169
//                  ---------------                   ------------
//                 |            SDA|<--------------->|SDA         |
//                 |     I2C    SCL|---------------->|SCL  I2C    |
//                 |   MASTER      |                 |    SLAVE   |
//                 |               |              GND|            |
//
//
//******************************************************************************
#include  <msp430x16x.h>

#define COM0                                // when define, use uart0
                                            // If not, use uart1

unsigned int Compare, Oldcapture;

char i,j,h = 0;
unsigned int k = 0;
char RR = 0xAA;
char loop_break = 0;
char D_NUM = 0x0F;
unsigned int dcount = 0X0000;
char RX_DATA[16];
char TX_DATA[16];
char CMD_BUF[17];
char cmd_counter=0;
char cmd_send = 0;
char dum;
char text_counter=0;
char seq[30];                               // test the sequency of interrupt
int  counter;

void SetDelay(void);

void SetI2cSpeed(void)
{
  I2CPSC = 0X07;
  I2CSCLL = I2CSCLH = 0X03;                 // 100K from 8M
}

void SetClkSys(void)
{
  BCSCTL1 &= ~XT2OFF;                       // XT2on

  do
  {
    IFG1 &= ~OFIFG;                         // Clear OSCFault flag
    for (i = 0xFF; i > 0; i--);             // Time for flag to set
  }
  while ((IFG1 & OFIFG));                   // OSCFault flag still set?

  BCSCTL2 |= SELM_2 + SELS;                 // MCLK= SMCLK= XT2 (safe)
}

void Init_IIC(void)
{
  P3SEL &= ~0x30;                           // P3.4,5 = USART0 TXD/RXD, UART0 NOT SELECT
  P3SEL |= 0x0A;                            // P3.1,3 = I2C, Assign I2C pins to module

  U0CTL |= SWRST;

  U0CTL |= I2C + SYNC;                      // Switch USART0 to I2C mode
  U0CTL &= ~I2CEN;                          // clear I2CEN bit => necessary to re-configure I2C module

  U0CTL &= ~XA;
  U0CTL &= ~LISTEN;
  U0CTL &= ~RXDMAEN;
  U0CTL &= ~TXDMAEN;

  I2CTCTL = 0X00;
  I2CTCTL = I2CSSEL_2 ;                     // smclk = mclk = 8 Mhz


  I2CIE   = TXRDYIE + NACKIE+ RXRDYIE + ARDYIE + STTIE + OAIE; // Enable I2C interrupts
  I2CIFG  =0x00;                            // clear I2C interrupt flags

  I2CSA = 0X0062;

  I2COA = 0x0049;

  I2CNDAT = D_NUM;                          // Read six bytes

  SetI2cSpeed();                            // set i2c speed

  U0CTL |= I2CEN;                           // Enable I2C

  IFG1 &= ~UTXIFG0;
  IFG1 &= ~URXIFG0;
}


void TxI2c(void)
{
  k = 0;
  counter = 0x0000;

  WDTCTL = WDT_ARST_1000;

  U0CTL |= MST;                             // Master mode
  I2CTCTL |= I2CSTT + I2CSTP + I2CTRX;      // Initiate  TX

  while (counter == 0x0000);
}

void RxI2c(void)
{
  k = 0;
  counter = 0x0000;

  WDTCTL = WDT_ARST_1000;

  U0CTL |= MST;                             // Master mode
  I2CTCTL &= ~I2CTRX;
  I2CTCTL |= I2CSTT + I2CSTP;               // Initiate RX

  while (counter == 0x0000);
}


void CheckTxRx(void)
{
  for(j =0; j <D_NUM; j++)                  // CHECK TXRX DATA
    if (RX_DATA[j] != TX_DATA[j])
    {
      P1OUT |= 0X01;
      while(1);
    }
}

void SetDelay(void)
{
  for ( dcount = 0; dcount <20000; dcount++)
  {
    _NOP();
  };

}

void InitUart0(void)
{
#ifdef COM0                                 // define usrt0

  P3DIR &= ~0XC0;                           //
  P3SEL &= ~0XC0;                           // RELEASE UART1

  P3OUT |= 0X30;
  P3DIR |= 0X30;                            // KEEP OUTPUT HIGH
  P3SEL |= 0x30;                            // P3.4,5 = USART0 TXD/RXD
  P3SEL &= ~0X0A;                           // P3.1,3 = I2C

  U0CTL &= ~SYNC;
  U0CTL &= ~SYNC;
  U0CTL |= SWRST;

  U0CTL = 0X01;                             // RESET ALL
  U0TCTL = 0X01;

  UCTL0 |= CHAR;                            // 8-bit character
  UTCTL0 |= SSEL1;                          // UCLK = SMCLK
  UBR00 = 0xA1;                             // 19200 from 8Mhz
  UBR10 = 0x01;                             //
  UMCTL0 = 0x00;                            // no modulation
  ME1 |= UTXE0 + URXE0;                     // Enabled USART0 TXD/RXD
  UCTL0 &= ~SWRST;                          // Initialize USART state machine

  IFG1 &= ~URXIFG0;
  IE1 |= URXIE0;                            // Enable USART0 RX interrupt

#else                                       // define uart1
  P3DIR &= ~0X30;                           //
  P3SEL &= ~0X30;                           // RELEASE UART0

  P3OUT |= 0XC0;
  P3DIR |= 0XC0;                            // keep output high

  P3SEL |= 0xC0;                            // P3.6,7 = USART1 TXD/RXD
  P3SEL &= ~0X0A;                           // P3.1,3 = I2C


  ME2 |= UTXE1 + URXE1;                     // Enable USART1 TXD/RXD
  UCTL1 |= CHAR;                            // 8-bit character
  UTCTL1 |= SSEL1;                          // UCLK = SMCLK

  UBR00 = 0xA1;                             // 19200 from 8Mhz
  UBR10 = 0x01;                             //

  UMCTL1 = 0x00;                            // modulation
  UCTL1 &= ~SWRST;                          // Initialize USART state machine

  IFG2 &= ~URXIFG1;
  IE2 |= URXIE1;                            // Enable USART1 RX interrupt

#endif
}

void SendCmd( char RXTX)
{
#ifdef COM0
  while( !(IFG1 & UTXIFG0));
  TXBUF0 = RXTX;                            // COMMAND

#else
  while( !(IFG2 & UTXIFG1));
  TXBUF1 = RXTX ;

#endif
}

void SendToDisplay( char RXTX)
{
  char temp;
  temp =  RXTX;
  temp &= 0xF0;
  temp >>= 4;

  if( temp > 9)
    temp = temp - 0x09 + 0x40;
  else
    temp = temp + 0x30;

#ifdef COM0
  while( !(IFG1 & UTXIFG0));
  TXBUF0 = temp;                            // COMMAND

#else
  while( !(IFG2 & UTXIFG1));
  TXBUF1 = temp ;

#endif
  temp =  RXTX;
  temp &= 0x0F;

  if( temp > 9)
    temp = temp - 0x09 + 0x40;
  else
    temp = temp + 0x30;

#ifdef COM0
  while( !(IFG1 & UTXIFG0));
  TXBUF0 = temp;                            // COMMAND

#else
  while( !(IFG2 & UTXIFG1));
  TXBUF1 = temp ;

#endif

#ifdef COM0
  while( !(IFG1 & UTXIFG0));
  TXBUF0 = 0x20;                            // space

#else
  while( !(IFG2 & UTXIFG1));
  TXBUF1 = 0x20 ;

#endif

  text_counter +=3;
}

void SetUart0(void)
{
  _DINT();
  InitUart0();

  _EINT();
  SetDelay();
}

void SetI2c(void)
{
  SetDelay();
  _DINT();

  Init_IIC();
  _EINT();

}

void NewLine(void)
{
  SendCmd(0X0A);                            // NEW LINE
  SendCmd(0x0D);                            // Back to beginning

#ifdef COM0
  while( !(IFG1 & UTXIFG0));
  text_counter = 0x00;
#else
  while( !(IFG2 & UTXIFG1));
  text_counter = 0x00;
#endif
}

void LoopTestRand(void)
{
  cmd_send = 0xDD;
   D_NUM = 0x0F;
  RR = 0x00;
  loop_break = 0x0F;
  while(1)
  {
    SetI2c();
    RR += 1;
    TxI2c();                                // send AA 55 AA 55 AA 55

    RxI2c();                                // receive 6 data from slave

    SetUart0();

    for(k = 0; k<D_NUM ; k++)
      SendToDisplay(RX_DATA[k]);

    NewLine();

    CheckTxRx();                            // check for correct I2C communication

    if (loop_break == 1) break;
  }
  P1OUT = ~0X01;
}

void ReceiveAll(void)
{
  D_NUM = 0X0F;

  SetI2c();

  RxI2c();                                  // receive 6 data from slave

  SetUart0();

  for(k = 0; k<D_NUM ; k++)
    SendToDisplay(RX_DATA[k]);

  NewLine();
}


void SendData(char temp)
{
  for( k = 0; k < temp; k++)
    TX_DATA[k] = CMD_BUF[k];

  D_NUM = temp;

  cmd_send = 0xEE;

  SetI2c();

  TxI2c();

  SetUart0();

  SendCmd(0x41);                            // A
  SendCmd(0x53);                            // S
  SendCmd(0x43);                            // C
  SendCmd(0x49);                            // I
  SendCmd(0x49);                            // I
  SendCmd(0x20);                            //
  SendCmd(0x73);                            // s
  SendCmd(0x65);                            // e
  SendCmd(0x6E);                            // n
  SendCmd(0x74);                            // t

  NewLine();
  D_NUM = 0x0F;
}


void LoopTestAA55(void)
{
  D_NUM = 0x0F;
  RR = 0x55;
  cmd_send = 0xAA;
  loop_break = 0x0F;
  while(1)
  {
    SetI2c();

    TxI2c();                                // send AA 55 AA 55 AA 55

    RxI2c();                                // receive 6 data from slave

    SetUart0();

    for(k = 0; k<D_NUM ; k++)
      SendToDisplay(RX_DATA[k]);

    NewLine();

    CheckTxRx();                            // check for correct I2C communication

    if (loop_break == 1) break;
  }
  P1OUT = ~0X01;
}

void Exec(void)
{

  if ( loop_break != 0x0F)
  {
    NewLine();
    if (cmd_counter == 3)
    {
      if (CMD_BUF[0] == 0x61)
       if (CMD_BUF[1] == 0x35)
       {
         LoopTestAA55();                    // command "a5", loop test AA 55
         cmd_counter = 0x20;
       }
      if (CMD_BUF[0] == 0x72)
      if (CMD_BUF[1] == 0x78)
      {
        ReceiveAll();                       // command "rx", get data
        cmd_counter = 0x20;
      }
    }
    if ( cmd_counter == 4)
    {
      if (CMD_BUF[0] == 0x63)
      if (CMD_BUF[1] == 0x6C)
      if ( CMD_BUF[2] == 0x72)
      {
        SendCmd(0x0C);                      // new page
        P1OUT = ~0X01;                      // OFF P1.0 LED
        cmd_counter = 0x20;                 // indicate command done
       }
    }

    if ( cmd_counter == 5)
    {
      if (CMD_BUF[0] == 0x72)
        if (CMD_BUF[1] == 0x61)
         if ( CMD_BUF[2] == 0x6E)
          if ( CMD_BUF[3] == 0x64)
          {
            LoopTestRand();                 // command "rand", loop test random
            cmd_counter = 0x20;             // indicate command done
          }
    }

    if (cmd_counter < 0x20 && cmd_counter >1)
    {
      SendData(cmd_counter-1);
    }
  }

  if (cmd_counter == 1)
  {
    cmd_counter = 0x20;                     // enter is pressed
    loop_break = 1;                         // break loop test
  }
  cmd_counter = 0;
}

void main(void)
{
  WDTCTL = WDTPW + WDTHOLD;                 // Stop watchdog

  SetClkSys();

  P5DIR |= 0x70;                            // P5.6,5,4 outputs
  P5SEL |= 0x70;                            // P5.6,5,4 options, TO SEE ACLK, SMCLK, MCLK RESPECTIVELY

  P2OUT  = 0X00;
  P2DIR &= 0X1F;                            // P2.7,6,5 AS INPUT

  P1OUT  = 0X00;
  P1DIR |= 0X01;

  P3DIR = 0X00;
  P3SEL = 0X00;
  P3OUT = 0XFF;

   SetUart0();
   SendCmd(0x0C);                           // new page

  SendCmd(0x44);                            // D
  SendCmd(0x65);                            // e
  SendCmd(0x76);                            // v
  SendCmd(0x69);                            // i
  SendCmd(0x63);                            // c
  SendCmd(0x65);                            // e
  SendCmd(0x20);                            //
  SendCmd(0x52);                            // R
  SendCmd(0x65);                            // e
  SendCmd(0x73);                            // s
  SendCmd(0x65);                            // e
  SendCmd(0x74);                            // t

  NewLine();

  while(1)
  {
    while ( (P1IN & 0X02)!= 0X02 );         // waiting for data signal
    SetI2c();
    RxI2c();                                // get data from slave

    SetUart0();                             // going to display it
    SendToDisplay(RX_DATA[0]);
    SendToDisplay(RX_DATA[1]);

    NewLine();
  }
}

#pragma vector=UART0RX_VECTOR
__interrupt void usart0_rx (void)
{
  char temp;
  while (!(IFG1 & UTXIFG0));                // USART0 TX buffer ready?
  temp   = RXBUF0;

  if(cmd_counter < 0x0F  && temp != 0x0D)
  {
    TXBUF0 = temp;
    CMD_BUF[cmd_counter] = temp; }

    cmd_counter +=1;
    if (cmd_counter > 0x10)                 // limited to 15 data + CR
    {
      cmd_counter = 0x10;
    }
  if (temp == 0x0D)
    Exec();

}


#pragma vector=UART1RX_VECTOR
__interrupt void usart1_rx (void)
{
  char temp;
  while (!(IFG2 & UTXIFG1));                // USART1 TX buffer ready?
  temp = RXBUF1;

  if(cmd_counter < 0x0F  && temp != 0x0D)
  {
    TXBUF1 = temp;
    CMD_BUF[cmd_counter] = temp;
  }

  cmd_counter +=1;
  if (cmd_counter > 0x10)                   // limited to 15 data + CR
  {
    cmd_counter = 0x10;
  }
  if (temp == 0x0D)
    Exec();

}

// USART0 I2C interrupt service routine
#pragma vector=USART0TX_VECTOR
__interrupt void I2C_IV (void)
{

  switch( I2CIV )
  {


  case 0x02:  k+=1;
              seq[k]= 0x02;
              break;                        // ALIFG: n/a
  case 0x04:  k+=1;
              seq[k]= 0x04;

              break;
                                            // NACKIFG: n/a
  case 0x06:  k+=1;
              seq[k]= 0x06;
               counter = 0x0000;

              break;                        // OAIFG: n/a

  case 0x08:  k+=1;
              seq[k]= 0x08;
              i = 0;
              counter = 0xff;
               WDTCTL = WDTPW + WDTHOLD;    // Stop watchdog

              break;                        // ARDYIFG: n/a

  case 0x0A:  k+=1;
              seq[k]= 0x0A;

              RX_DATA[i] = I2CDRB;
              i+=1;

              break;
                                            // RXRDYIFG: n/a

  case 0x0C:
              if (cmd_send == 0xDD)
              {
                I2CDRB = RR;                // rand test
                TX_DATA[i] = RR ;
                RR += 1;
              }
              if (cmd_send == 0xAA)
              {
                RR ^= 0XFF ;                // AA 55
                I2CDRB = RR;                // AA55 test
                TX_DATA[i] = RR ;

              }
              if (cmd_send == 0xEE)
                I2CDRB = TX_DATA[i];        // send data
              i+=1;
              break;                        // TXRDYIFG: n/a

  case 0x0E:  k+=1;
              seq[k]= 0x0E;
              break;                        // GCIFG: n/a

  case 0x10:  k+=1;
              seq[k]= 0x10;
              break;                        // STTIFG: n/a
  }

}
