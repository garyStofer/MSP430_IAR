//------------------------------------------------------------------------------
// Name: IrDAPrimaryDemo.cpp
// Func: PC demo application for establishing an infrared connection using
//       the Windows 2000/XP built-in IrDA functionality. The program is part
//       of the MSP430 IrDA application note
// Ver.: 1.0
// Date: February 2004
// Auth: Andreas Dannenberg
//       MSP430 Applications
//       Texas Instruments Inc.
// Rem.: - File can be build with any common Win32 compiler such as Borland
//         C++ or Microsoft Visual C++
//       - To successful build this project, the header file 'Af_irda.h'
//         has to be in the include search path. If this file is not part of
//         your Windows header files collection, you can obtain it by
//         downloading the latest version of the Microsoft Source Development
//         Kit ("Windows Core SDK") from http://msdn.microsoft.com/downloads
//       - For documentation about the Windows IrDA support including function
//         calls, structures etc., please refer to the Windows Core SDK
//       - Parts of this file are based on code examples from the Microsoft
//         Windows Core SDK documentation.
//------------------------------------------------------------------------------

// Standard C header files
#include <stdio.h>
#include <string.h>

// Windows header files
#define _WIN32_WINNT 0x0500                     // Build for NT5.0+
#define WIN32_LEAN_AND_MEAN 1

#include <windows.h>                            // General windows stuff
#include <winsock2.h>                           // Windows sockets
#include <Af_irda.h>                            // IrDA headers

int main(int argc, char* argv[])
{
  WORD wVersionRequested;
  WSADATA wsaData;
  int err;
  int ReturnValue = 0;

  printf("IrDA PC Demo Application V1.0\n");
  printf("Andreas Dannenberg\n");
  printf("MSP430 Applications\n");
  printf("Texas Instruments Inc.\n\n");
 
  wVersionRequested = MAKEWORD(2, 2);

  err = WSAStartup(wVersionRequested, &wsaData);
  if (err != 0)
  {
    // Tell the user that we could not find a usable WinSock DLL
    printf("Can't find usable WinSock DLL!\n");
    return 1;
  }

  // Confirm that the WinSock DLL supports 2.2.
  // Note that if the DLL supports versions greater
  // than 2.2 in addition to 2.2, it will still return
  // 2.2 in wVersion since that is the version we
  // requested.
  if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2)
  {
    // Tell the user that we could not find a usable WinSock DLL
    printf("Can't find usable WinSock DLL!\n");
    WSACleanup();
    return 1;
  }

  // The WinSock DLL is acceptable. Proceed.
  #define DEVICE_LIST_LEN 5

  // IrDA discovery buffer
  BYTE          DevListBuff[sizeof(DEVICELIST) - sizeof(IRDA_DEVICE_INFO) +
                           (sizeof(IRDA_DEVICE_INFO) * DEVICE_LIST_LEN)];
  int           DevListLen = sizeof(DevListBuff);
  PDEVICELIST   pDevList = (PDEVICELIST)&DevListBuff;
  
  #define IAS_QUERY_ATTRIB_MAX_LEN 32

  // Buffer for IrDA IAS query
  BYTE          IASQueryBuff[sizeof(IAS_QUERY) - 3 + IAS_QUERY_ATTRIB_MAX_LEN];
  int           IASQueryLen = sizeof(IASQueryBuff);
  PIAS_QUERY    pIASQuery = (PIAS_QUERY)&IASQueryBuff;

  // Vars for searching through peers IAS response
  BOOL          Found = FALSE;
  UCHAR         *pPI, *pPL, *pPV;

  // Var for the setsockopt call to enable 9-wire IrCOMM
  int           Enable9WireMode = 1;

  // Client's Windows socket
  SOCKET Sock;
  int RcvTimeOut = 3000;
  int SndTimeOut = 3000;

  SOCKADDR_IRDA DstAddrIR = { AF_IRDA, 0, 0, 0, 0, "IrDA:IrCOMM" };
  
  // Misc vars for IrDA communication
  int BytesRead;
  int BytesSent;
  char Buffer[256];
  
  // Open socket
  printf("socket()...");
  if ((Sock = socket(AF_IRDA, SOCK_STREAM, 0)) == INVALID_SOCKET)
  {
    printf("Failed. Error code %i\n", WSAGetLastError());
    return 1;                                   // No closesocket() needed here
  }
  printf("OK.\n");  

  // Set socket options
  printf("setsockopt() [TIMEOUTS]...");
  if ((setsockopt(Sock, SOL_SOCKET, SO_RCVTIMEO, (char *)&RcvTimeOut,
       sizeof(int)) == SOCKET_ERROR) ||
      (setsockopt(Sock, SOL_SOCKET, SO_SNDTIMEO, (char *)&SndTimeOut,
       sizeof(int)) == SOCKET_ERROR))
  {
    printf("Failed. Error code %i.\n", WSAGetLastError());
    ReturnValue = 1;
    goto GracefulClose;
  }
  printf("OK.\n");  

  // Search for the peer device
  pDevList->numDevice = 0;
  printf("getsockopt() [IRLMP_ENUMDEVICES]...");
  if (getsockopt(Sock, SOL_IRLMP, IRLMP_ENUMDEVICES, (CHAR *)pDevList,
      &DevListLen) == SOCKET_ERROR)
  {
    printf("Failed. Error code %i.\n", WSAGetLastError());
    ReturnValue = 1;
    goto GracefulClose;
  }
  printf("OK.\n");  

  if (pDevList->numDevice == 0)
  {
    // No devices found, tell the user
    printf("Application error: no IrDA devices found.\n");
    ReturnValue = 1;
    goto GracefulClose;
  }

  // Assume first device, we should have a common dialog here
  memcpy(&DstAddrIR.irdaDeviceID[0], &pDevList->Device[0].irdaDeviceID[0], 4);

  // Query the peer to check for 9wire IrCOMM support
  memcpy(&pIASQuery->irdaDeviceID[0], &pDevList->Device[0].irdaDeviceID[0], 4);

  // IrCOMM IAS attributes
  memcpy(&pIASQuery->irdaClassName[0],  "IrDA:IrCOMM", 12);
  memcpy(&pIASQuery->irdaAttribName[0], "Parameters",  11);

  printf("getsockopt() [IRLMP_IAS_QUERY]...");
  if (getsockopt(Sock, SOL_IRLMP, IRLMP_IAS_QUERY, (char *)pIASQuery,
                 &IASQueryLen) == SOCKET_ERROR)
  {
    printf("Failed. Error code %i.\n", WSAGetLastError());
    ReturnValue = 1;
    goto GracefulClose;
  }
  printf("OK.\n");

  if (pIASQuery->irdaAttribType != IAS_ATTRIB_OCTETSEQ)
  {
    // Peer's IAS database entry for IrCOMM is bad error
    printf("Application error: peer's IAS database entry for IrCOMM is bad.\n");
    ReturnValue = 1;
    goto GracefulClose;
  }

  if (pIASQuery->irdaAttribute.irdaAttribOctetSeq.Len < 3)
  {
    // Peer's IAS database entry for IrCOMM is bad error
    printf("Application error: peer's IAS database entry for IrCOMM is bad.\n");
    ReturnValue = 1;
    goto GracefulClose;
  }

  // Search for the PI value 0x00 and check 9 wire, see IrCOMM spec.
  pPI = pIASQuery->irdaAttribute.irdaAttribOctetSeq.OctetSeq;
  pPL = pPI + 1;
  pPV = pPI + 2;

  while (1)
  {
    if (*pPI == 0 && (*pPV & 0x04))
    {
      Found = TRUE;
      break;
    }

    if (pPL + *pPL >= pIASQuery->irdaAttribute.irdaAttribOctetSeq.OctetSeq +
                      pIASQuery->irdaAttribute.irdaAttribOctetSeq.Len)
    {
      break;
    }

    pPI = pPL + *pPL;
    pPL = pPI + 1;
    pPV = pPI + 2;
  }

  if (!Found)
  {
    // Peer doesn't support 9-wire mode error
    printf("Application error: peer doesn't support 9 wire mode.\n");
    ReturnValue = 1;
    goto GracefulClose;
  }

  // Enable 9-wire mode before connect()
  printf("setsockopt() [IRLMP_9WIRE_MODE]...");
  if (setsockopt(Sock, SOL_IRLMP, IRLMP_9WIRE_MODE,
      (const char *)&Enable9WireMode, sizeof(int)) == SOCKET_ERROR)
  {
    printf("Failed. Error code %i\n", WSAGetLastError());
    ReturnValue = 1;
    goto GracefulClose;
  }
  printf("OK.\n");

  // Nothing special for IrCOMM from now on...
  printf("connect()...");
  if (connect(Sock, (const struct sockaddr *)&DstAddrIR,
      sizeof(SOCKADDR_IRDA)) == SOCKET_ERROR)
  {
    printf("Failed. Error code %i.\n", WSAGetLastError());
    ReturnValue = 1;
    goto GracefulClose;
  }
  printf("OK.\n");

  // Send 't' to IrDA peer (MSP430)
  printf("send()...");
  if ((BytesSent = send(Sock, "t", 1, 0)) == SOCKET_ERROR)
  {
    printf("Failed. Error code %i.\n", WSAGetLastError());
    ReturnValue = 1;
    goto GracefulClose;
  }
  printf("OK.\n");

  // Wait for IrDA peer to provide data
  Sleep(500);

  // Receive up to 255 data bytes from IrDA peer
  printf("recv()...");
  if ((BytesRead = recv(Sock, Buffer, sizeof(Buffer) - 1, 0)) == SOCKET_ERROR)
  {
    printf("Failed. Error code %i.\n", WSAGetLastError());
    ReturnValue = 1;
    goto GracefulClose;
  }
  printf("OK.\n");

  if (BytesRead)
  {
    Buffer[BytesRead] = 0;   // Make sure string is terminated
    printf("Application data received (%i bytes): %s\n", BytesRead, Buffer);
  }
  else
  {
    printf("Application error: no data received.\n");
    ReturnValue = 1;
  }

GracefulClose:
  // Close socket
  printf("closesocket()...");
  if (closesocket(Sock) == SOCKET_ERROR)
  {
    printf("Failed. Error code %i.\n", WSAGetLastError());
    return 1;
  }

  printf("OK.\n");
	return ReturnValue;
}
