File description
----------------
water_meter.s43    - source file in IAR asm
water_meter.prj    - IAR project file

Installion
----------
1. Get the free IAR Kickstart software tools from TI MSP430 web site.

	http://www.ti.com/sc/msp430

2. Install the software
3. Start IAR Embedded Workbench
4. Open water_meter.prj
5. Connect FET tools to target board
6. Start C-SPY which automatically download code to MSP430F41x
7. Start emulation
8. Or do stanalone running by disconnecting FET from target board

(Note : please refer to IAR Manual for detail operation of IAR software.)

