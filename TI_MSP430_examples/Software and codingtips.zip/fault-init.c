/*
  This code shows a one-time check of the oscillator fault flag, implemented
  after a power-on reset (POR).  It's designed to ensure that a low-frequency
  crystal attached to LFXT1 has stabilized before execution continues.

  The code also uses  that the DCO has fully synchronized with the 32kHz
  crystal before the device goes into LPM3.  This is necessary because
  '4xx devices have a hardware FLL that synchronize the DCO with the
  LFTX1 frequency, and the FLL does not operate in ISRs.  Since all CPU
  execution in this program takes place within ISRs after the initial setup,
  the DCO may remain stuck at the wrong frequency if not given time to
  synchronize before entering LPM3.  At most, this synchronization may take
  28*32 ACLK cycles (per the '4xx User's Guide).  We can either change MCLK to
  be sourced from ACLK temporarily and count 896 cycles, or continue to use the
  DCO as MCLK but use a safe, high value.  This program does the latter.

  The code iteratively clears OFIFG, waits, then checks again.  It
  continues this until approximately a second has elapsed, long enough for
  most watch crystals.

  If it still hasn't cleared after doing this delayCycles times, a
  handler executes.  In this case, an output is turned high and the device
  goes into eternal sleep.  Once it does start up properly, it is used to
  oscillate the output.

  Using delayCycles to limit the number of checking iterations allows the
  program to report the error to the user.  A simpler version of this code
  could make the checking loop endless, in which case the program would lock
  up if the oscillator failed to start.

  Note that SMCLK is used for the OFIFG fault-checking, and ACLK is used for
  the main function.  SMCLK is derived from the DCO by default; until the xtal
  oscillator can be trusted, the DCO should be used.

                 MSP430F413
             -----------------
         /|\|              XIN|-
          | |                 | 32kHz
          --|RST          XOUT|-
            |                 |
            |             P5.1|-->LED

*/


#include <msp430x41x.h>

void main(void)
{
  unsigned int delayCycles = 20;
  unsigned int i;

  WDTCTL = WDTPW + WDTHOLD;                 // Stop WDT
  FLL_CTL0 |= XCAP14PF;                     // Configure load caps
  P5DIR = 0x02;                             // Configure LED output

  // Wait for watch crystal to stabilize....
  while ((IFG1&OFIFG) && (delayCycles > 0)) // While osc in fault and while
  {                                         // haven't used up all cycles...
    delayCycles--;                          // Decr the counter
    IFG1 &= ~OFIFG;                         // Clear OFIFG
    for(i=0x47FF;i>0;i--);                  // Now wait & see if it sets again
  }

  // If still not stable, something's wrong.  Handle it.
  if (OFIFG&IFG1)
  {
    P5OUT = 0x02;                           // Communicate to user bad osc
    _BIS_SR(LPM4_bits + GIE);               // Eternal sleep
  }

  for (i=0x1BB2;i>0;i--);                   // Now with stable ACLK, give ample
                                            // time for DCO to synchronize.
  // Main function
  TACCTL0 = CCIE;                           // Enable CCR0 interrupt
  TACCR0 = 16384;                           // Value for delay of ~half sec
  TACTL = TASSEL_1+TACLR +MC_1;             // ACLK=32kHz; TAR=0; up mode, GO

  _BIS_SR(LPM3_bits + GIE);                 // Go to sleep

}


// CCR0 Interrupt service routine
#pragma vector=TIMERA0_VECTOR
__interrupt void CCR0_ISR(void)
{
    P5OUT ^= 0x02;
    TACTL |= TACLR;           // ACLK=32kHz; TAR=0; up mode, GO
}
