/*
  This example shows a case where the declared memory is so large that the
  resulting C program will go into an endless watchdog loop, unless something
  is done to prevent it.  In this example, because one memory element is at
  the root of the problem, it would be easier to simply use a "no init"
  directive on it (__no_init in IAR).  If such a directive isn't available, or
  if there are numerous smaller elements causing the problem, a "low level
  init" directive can be used to move the watchdog configuration to the very
  beginning of execution.


                MSP430F1612
             -----------------
         /|\|              XIN|-
          | |                 |
          --|RST          XOUT|-
            |                 |
            |             P1.0|-->LED

*/


#include <msp430x16x.h>

int x_array[2500];                          // This will take >32ms to
                                            // initialize.  32ms is the default
                                            // period before the watchdog
                                            // resets the device.
unsigned int i,x;

void main(void)
{
  //WDTCTL = WDTPW+WDTHOLD;                 // If placed here instead of
                                            // __low_level_init(), execution
                                            // will go into an endless loop

  P1DIR = 0x01;                             // Configure as output for LED
  x_array[0] = 1;                           // If array not used, compiler
                                            // will not create it

  // Loop causes LED to flash like a spinning wheel; fast at first,
  // slowing to a crawl, iteratively
  while(1)
  {
    P1OUT ^= 0x01;                          // Toggle the LED
    TACCR1=TACCR1+400;                      // Increase delay time
    if(TACCR1>18000) TACCR1=0;              // Roll over when it gets too slow

    TACCTL1 = CCIE;                         // Compare mode, enable interrupt
    TACTL = TASSEL_2 + TACLR + +ID_3 + MC_2;// SMCLK/4, TAclear, cont mode
    _BIS_SR(LPM0_bits+GIE);                 // Enter LPM0, wait for CCR1 int
  }
}


// IAR-standard function will be executed prior to initializing memory space
void __low_level_init(void)
{
  WDTCTL = WDTPW+WDTHOLD;                   // Stop watchdog timer
}


// Timer A1 interrupt service routine
#pragma vector=TIMERA1_VECTOR
__interrupt void Timer_A(void)
{
   _BIC_SR_IRQ(LPM0_bits);                  // Exit LPM0 on reti
   CCTL1 &= ~CCIFG;                         // Clear CCR1 interrupt flag
}