/*
  This code shows a way to increase the DCO frequency to a frequency near
  6MHz while ensuring that Vcc has ramped to a safe level before doing so.

  The target device is MSP430FG439.  The datasheet indicates that 2.9V is
  safe for 6MHz operation (Vcc-min).

  The program first waits a fixed period for the ramp to exceed 1.8V.  On-chip
  components, including the CPU, are guaranteed to operate at 1.8V+, but could
  start operating before.  The fixed delay is necessary in case the CPU starts
  but the SVS is not yet properly powered.

  Then, the SVS can be used to ensure Vcc has reached Vcc-min for the given
  clock speed.  The program sets the SVS threshold value, then waits for SVSON
  to be set, per the '4xx User's Guide.  After this, it iteratively
  clears/checks SVSFG until it stays clear.  The DCO frequency can then be
  increased.


                MSP430FG439
             -----------------
         /|\|              XIN|-
          | |                 |
          --|RST          XOUT|-
            |                 |
     LED <--|P1.0         P1.1|--> MCLK out
*/


#include <msp430x43x.h>

void main(void)
{
  unsigned int i;

  WDTCTL = WDTPW + WDTHOLD;                 // Stop watchdog timer

  P1DIR = 0x03;
  P1SEL = 0x02;                             // Allows probing P1.1 to see MCLK

  for(i=5000;i>0;i--);                      // Fixed delay ~20-40ms for Vcc to
                                            // rise >1.8V. This value should be
                                            // customized to the system's ramp

  // After the fixed delay, SVS is a secondary check of Vcc
  SVSCTL = 0x90;                            // Vcc-min=2.9V, safe for 6MHz
  while(!(SVSCTL&SVSON));                   // Wait for t-d(SVSon) and t-settle
  while(SVSCTL&SVSFG)                       // If Vcc<Vcc-min, SVSFG will
    SVSCTL &= ~SVSFG;                       // immediately be set again

  // Vcc has now arrived at the required level.  Increase DCO frequency.
  SCFQCTL = 91;                             // (90+1) x 32768 x 2 = 5.96MHz
  FLL_CTL0 |= DCOPLUS;                      // DCO+ set so freq= xtal x D x N+1

  // program code
  // .
  // .
  // .

  P1OUT = 0x01;                             // Shows ~6MHz execution has begun
  _BIS_SR(LPM4_bits);                       // Sleep
}
