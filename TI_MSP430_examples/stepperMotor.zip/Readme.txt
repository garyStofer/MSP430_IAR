List of files:

Stepper Motor Controller.sch - Schematic drawn using Eagle 4.11
Stepper Motor Controller.brd - Board layout file drawn using Eagle 4.11
Stepper Motor BOM.xls - Bill of Material
stepper_motor_IAR.c - Source code file for IAR Embedded Workbench
stepper_motor_CCE.c - Source code file for Code Composer Essentials
MSP430_Stepper_Motor_Controller_PCB_Files - Directory containing files used to build PCB


Notes:

MSP430 Stepper Motor Controller boards were built by PCBexpress (www.pcbexpress.com)