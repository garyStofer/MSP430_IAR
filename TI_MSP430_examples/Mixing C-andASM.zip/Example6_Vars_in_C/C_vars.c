/* This file only contains definitions of the variables 
   which are used by the assembler Program */

//             RSEG     UDATA0  
unsigned int Varword1;  // Varword1      DS  2
unsigned int Varword2;  // Varword2      DS  2
unsigned int Varword3;  // Varword3      DS  2

char Varbyte1;          // Varbyte1      DS  1
char Varbyte2;          // Varbyte2      DS  1
char Varbyte3;          // Varbyte3      DS  1

